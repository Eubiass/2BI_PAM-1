﻿using System;
using Microsoft.Maui.Controls;

namespace CalculadoraCompleta2
{
    public partial class MainPage : ContentPage
    {
        string entradaAtual = "";
        string operador = "";
        double resultadoParcial = 0;
        bool novoNumero = true;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnNumberClicked(object sender, EventArgs e)
        {
            var botao = (Button)sender;
            string numero = botao.Text;

            if (novoNumero)
            {
                lblDisplay.Text = numero;
                novoNumero = false;
            }
            else
            {
                lblDisplay.Text += numero;
            }

            entradaAtual = lblDisplay.Text;
        }

        private void OnOperatorClicked(object sender, EventArgs e)
        {
            var botao = (Button)sender;
            operador = botao.Text;

            if (double.TryParse(lblDisplay.Text, out double numero))
            {
                resultadoParcial = numero;
                novoNumero = true;
            }
        }

        private void OnClearClicked(object sender, EventArgs e)
        {
            lblDisplay.Text = "0";
            entradaAtual = "";
            operador = "";
            resultadoParcial = 0;
            novoNumero = true;
        }

        private void OnBackspaceClicked(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(lblDisplay.Text) && lblDisplay.Text.Length > 1)
            {
                lblDisplay.Text = lblDisplay.Text[..^1];
            }
            else
            {
                lblDisplay.Text = "0";
            }

            entradaAtual = lblDisplay.Text;
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {
            if (double.TryParse(lblDisplay.Text, out double numero))
            {
                double resultadoFinal = 0;

                switch (operador)
                {
                    case "+": resultadoFinal = resultadoParcial + numero; break;
                    case "-": resultadoFinal = resultadoParcial - numero; break;
                    case "X": resultadoFinal = resultadoParcial * numero; break;
                    case "/":
                        if (numero == 0)
                        {
                            lblDisplay.Text = "Erro";
                            novoNumero = true;
                            return;
                        }
                        resultadoFinal = resultadoParcial / numero;
                        break;
                    case "%":
                        resultadoFinal = (resultadoParcial * numero) / 100;
                        break;
                    default: return;
                }

                lblDisplay.Text = resultadoFinal % 1 == 0
                    ? ((int)resultadoFinal).ToString()
                    : resultadoFinal.ToString();

                resultadoParcial = resultadoFinal;
                novoNumero = true;
            }
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);
            lblDisplay.FontSize = width > height ? 36 : 48;
        }
    }
}

